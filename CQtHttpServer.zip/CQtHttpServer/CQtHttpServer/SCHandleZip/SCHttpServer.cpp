#include "SCHttpServer.h"

#include <QBuffer>

#include "JlCompress.h"

const QString strExtractDir = "D:/SeerGroup";

SCHttpServer::SCHttpServer(qint16 port, QObject *parent) : QObject(parent), m_nPort(port)
{
    init();
}

SCHttpServer::~SCHttpServer()
{
    unInit();
}


void SCHttpServer::init()
{
    m_pHttpServer = new QHttpServer;
    connect(m_pHttpServer, &QHttpServer::signalZipDataReceived, this, &SCHttpServer::onZipDataReceived);

    m_pHttpServer->route("/wj", QHttpServerRequest::Method::GET, []()
    {
        return "a";
    });

    m_pHttpServer->route("/postZip", QHttpServerRequest::Method::POST, []()
    {
        return "1";
    });

    quint16 port = m_pHttpServer->listen(QHostAddress::Any,m_nPort);
    if (!port)
        qCritical() << "Http server listen failed";
    else
        qDebug()<<"urlBase:"<< QStringLiteral("http://localhost:%1").arg(port);
}

void SCHttpServer::unInit()
{
    if(m_pHttpServer)
    {
        delete m_pHttpServer;
        m_pHttpServer = nullptr;
    }
}

// 当服务器接收到压缩文件时，解压压缩文件覆盖原有文件
void SCHttpServer::onZipDataReceived(QByteArray* body)
{
    JlCompress::extractDir(new QBuffer(body), strExtractDir);
}
