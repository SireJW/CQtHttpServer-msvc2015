﻿#include <QtCore>

#include "SCHttpServer.h"

#include "JlCompress.h"

// 客户端传压缩文件过来
// 我接收压缩文件，并将压缩文件解压覆盖现有文件
int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    SCHttpServer httpServer(7109);

    return app.exec();
}
