#ifndef SCHTTPSERVER_H
#define SCHTTPSERVER_H

#include <QObject>

#include "qhttpserver.h"

class SCHttpServer : public QObject
{
    Q_OBJECT
public:
    explicit SCHttpServer(qint16 port, QObject *parent = nullptr);
    ~SCHttpServer();

private:
    void init();
    void unInit();

private slots:
    void onZipDataReceived(QByteArray* body);

private:
    QHttpServer* m_pHttpServer{Q_NULLPTR};
    qint16 m_nPort;
};

#endif // SCHTTPSERVER_H
