/****************************************************************************
** Meta object code from reading C++ file 'qhttpserverrequest.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.11)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../CQtHttpServer/httpserver/httpserver/qhttpserverrequest.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qhttpserverrequest.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.11. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QHttpServerRequest_t {
    QByteArrayData data[21];
    char stringdata0[140];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QHttpServerRequest_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QHttpServerRequest_t qt_meta_stringdata_QHttpServerRequest = {
    {
QT_MOC_LITERAL(0, 0, 18), // "QHttpServerRequest"
QT_MOC_LITERAL(1, 19, 6), // "Method"
QT_MOC_LITERAL(2, 26, 7), // "Unknown"
QT_MOC_LITERAL(3, 34, 3), // "Get"
QT_MOC_LITERAL(4, 38, 3), // "Put"
QT_MOC_LITERAL(5, 42, 6), // "Delete"
QT_MOC_LITERAL(6, 49, 4), // "Post"
QT_MOC_LITERAL(7, 54, 4), // "Head"
QT_MOC_LITERAL(8, 59, 7), // "Options"
QT_MOC_LITERAL(9, 67, 5), // "Patch"
QT_MOC_LITERAL(10, 73, 7), // "Connect"
QT_MOC_LITERAL(11, 81, 3), // "All"
QT_MOC_LITERAL(12, 85, 3), // "GET"
QT_MOC_LITERAL(13, 89, 3), // "PUT"
QT_MOC_LITERAL(14, 93, 6), // "DELETE"
QT_MOC_LITERAL(15, 100, 4), // "POST"
QT_MOC_LITERAL(16, 105, 4), // "HEAD"
QT_MOC_LITERAL(17, 110, 7), // "OPTIONS"
QT_MOC_LITERAL(18, 118, 5), // "PATCH"
QT_MOC_LITERAL(19, 124, 7), // "CONNECT"
QT_MOC_LITERAL(20, 132, 7) // "Methods"

    },
    "QHttpServerRequest\0Method\0Unknown\0Get\0"
    "Put\0Delete\0Post\0Head\0Options\0Patch\0"
    "Connect\0All\0GET\0PUT\0DELETE\0POST\0HEAD\0"
    "OPTIONS\0PATCH\0CONNECT\0Methods"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QHttpServerRequest[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, alias, flags, count, data
       1,    1, 0x0,   18,   24,
      20,    1, 0x1,   18,   60,

 // enum data: key, value
       2, uint(QHttpServerRequest::Unknown),
       3, uint(QHttpServerRequest::Get),
       4, uint(QHttpServerRequest::Put),
       5, uint(QHttpServerRequest::Delete),
       6, uint(QHttpServerRequest::Post),
       7, uint(QHttpServerRequest::Head),
       8, uint(QHttpServerRequest::Options),
       9, uint(QHttpServerRequest::Patch),
      10, uint(QHttpServerRequest::Connect),
      11, uint(QHttpServerRequest::All),
      12, uint(QHttpServerRequest::GET),
      13, uint(QHttpServerRequest::PUT),
      14, uint(QHttpServerRequest::DELETE),
      15, uint(QHttpServerRequest::POST),
      16, uint(QHttpServerRequest::HEAD),
      17, uint(QHttpServerRequest::OPTIONS),
      18, uint(QHttpServerRequest::PATCH),
      19, uint(QHttpServerRequest::CONNECT),
       2, uint(QHttpServerRequest::Unknown),
       3, uint(QHttpServerRequest::Get),
       4, uint(QHttpServerRequest::Put),
       5, uint(QHttpServerRequest::Delete),
       6, uint(QHttpServerRequest::Post),
       7, uint(QHttpServerRequest::Head),
       8, uint(QHttpServerRequest::Options),
       9, uint(QHttpServerRequest::Patch),
      10, uint(QHttpServerRequest::Connect),
      11, uint(QHttpServerRequest::All),
      12, uint(QHttpServerRequest::GET),
      13, uint(QHttpServerRequest::PUT),
      14, uint(QHttpServerRequest::DELETE),
      15, uint(QHttpServerRequest::POST),
      16, uint(QHttpServerRequest::HEAD),
      17, uint(QHttpServerRequest::OPTIONS),
      18, uint(QHttpServerRequest::PATCH),
      19, uint(QHttpServerRequest::CONNECT),

       0        // eod
};

QT_INIT_METAOBJECT const QMetaObject QHttpServerRequest::staticMetaObject = { {
    nullptr,
    qt_meta_stringdata_QHttpServerRequest.data,
    qt_meta_data_QHttpServerRequest,
    nullptr,
    nullptr,
    nullptr
} };

QT_WARNING_POP
QT_END_MOC_NAMESPACE
